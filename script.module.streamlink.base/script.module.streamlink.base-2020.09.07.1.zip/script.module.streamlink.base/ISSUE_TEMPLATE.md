### Checklist

- [x] This is a bug report.
- [ ] This is a feature request.

### System tested on

...

### Expected / Actual behavior

...

### Explicit stream URLs to test

1. ...
2. ...
3. ...

### Logs

Make sure to **remove username and password**
You can upload your logs to <https://gist.github.com/> or below

```
REPLACE THIS TEXT WITH YOUR LOG
```

### Comments, screenshots, etc.

...
