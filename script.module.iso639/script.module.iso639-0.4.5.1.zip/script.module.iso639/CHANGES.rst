Changelog
---------

0.4.5
~~~~~
- Support LC_ALL=C

0.4.4
~~~~~
- Changed ``retired`` to { 'code': (``datetime``, [``_Language``, ...], 'description') }

0.4.3
~~~~~
- ISO 639-3 files updated

0.4.2
~~~~~
- Published to PyPI
- Declare ``__version__``
- Convert ``_Language`` object's ``names`` attribute to list

0.4.1
~~~~~
- ISO 639-3 files updated
