# -*- coding: utf-8 -*-

'''
	Thor Add-on
'''

import json, ntpath, os, sys, re, urlparse, urllib, resolveurl, xbmc, xbmcaddon, xbmcgui, zipfile

from urlparse import parse_qsl
from urllib import quote_plus
from sys import argv


from resources.lib.indexers import thorstreams, navigator, movies, seasons, episodes, tvshows, collections, swift, furk, youtube, tmdb

from resources.lib.modules import control, views, sources, sources2, downloader, trakt
from resources.lib.modules import playlist, libtools, trakt, youtube, playcount 
from resources.lib.modules import changelog, cache, debrid, notify, trailer


params = dict(parse_qsl(argv[2].replace('?','')))
action = params.get('action')

subid = params.get('subid')
name = params.get('name')
title = params.get('title')
year = params.get('year')
imdb = params.get('imdb')
tvdb = params.get('tvdb')
tmdb = params.get('tmdb')
season = params.get('season')
episode = params.get('episode')
tvshowtitle = params.get('tvshowtitle')
premiered = params.get('premiered')
url = params.get('url')
image = params.get('image')
meta = params.get('meta')
art = params.get('art')
select = params.get('select')
query = params.get('query')
source = params.get('source')
content = params.get('content')
table = params.get('table')

windowedtrailer = params.get('windowedtrailer')
windowedtrailer = int(windowedtrailer) if windowedtrailer in ("0","1") else 0
notificationSound = False if control.setting('notification.sound') == 'false' else True

if action is None:
	run = control.setting('first.info')
	if run == '':
		run = 'true' #clean install scenerio
	if cache._find_cache_version():
		run = 'true'  #check whether plugin.video.thor has been updated-use to be for script.module.thor
	if run == 'true':
		changelog.get()
		control.setSetting(id='first.info', value='false')
	cache.cache_version_check()
	navigator.navigator().root()

####################################################
#---News and Updates
####################################################
elif action == 'infoCheck'				: navigator.navigator().infoCheck('')
elif action == 'ShowNews'				: newsinfo.news()
elif action == 'ShowChangelog'			: changelog.get()

####################################################
#---My Lists
####################################################
elif action == 'lists'					: thorstreams.indexer().root()
elif action == '247'					: thorstreams.indexer().root_247()
elif action == '4k'						: thorstreams.indexer().root_4k()
elif action == '3d'						: thorstreams.indexer().root_3d()
elif action == '1clickcollections'		: thorstreams.indexer().root_1clickcollections()
elif action == 'herplace'				: thorstreams.indexer().root_herplace()
elif action == 'kids'					: thorstreams.indexer().root_kids()
elif action == 'space'					: thorstreams.indexer().root_space()
elif action == 'comedy'					: thorstreams.indexer().root_comedy()
elif action == '1clicks'				: thorstreams.indexer().root_1click()
elif action == 'music'					: thorstreams.indexer().root_music()
elif action == 'fitness'				: thorstreams.indexer().root_fitness()
elif action == 'food'					: thorstreams.indexer().root_food()
elif action == 'movielists'				: thorstreams.indexer().root_movielists()
elif action == 'sports'					: navigator.navigator().sports()
elif action == 'iptv'					: navigator.navigator().iptv()
elif action == 'purplehat'				: thorstreams.indexer().root_purplehat()

elif action == 'private'				: thorstreams.indexer().pmode()  
elif action == 'directory'				: thorstreams.indexer().get(url)
elif action == 'qdirectory'				: thorstreams.indexer().getq(url)
elif action == 'xdirectory'				: thorstreams.indexer().getx(url)
elif action == 'developer'				: thorstreams.indexer().developer()
elif action == 'tvtuner'				: thorstreams.indexer().tvtuner(url)
#elif 'youtube' in str(action)			: thorstreams.indexer().youtube(url, action)
elif action == 'traktNav'				: navigator.navigator().trakt_user()
#elif action == 'browser'				: thorstreams.resolver().browser(url)
#elif action == 'search'					: thorstreams.indexer().search(url=None)
#elif action == 'addSearch'				: thorstreams.indexer().addSearch(url)
#elif action == 'delSearch'				: thorstreams.indexer().delSearch()
elif action == 'traktlist'				: navigator.navigator().traktlist()
elif action == 'imdblist'				: navigator.navigator().imdblist()
elif action == 'imdbtop250'				: navigator.navigator().imdbtop250()
elif action == 'hodgepodge'				: navigator.navigator().hodgepodge()
elif action == 'hacktheplanet'			: navigator.navigator().hacktheplanet()
elif action == 'thorlist'				: navigator.navigator().thorlist()
elif action == 'boxsets'				: navigator.navigator().boxsets()
elif action == 'sportsNavigator'		: navigator.navigator().sports()

elif action == 'titan'					: thorstreams.indexer().root_titan()
elif action == 'porn'					: thorstreams.indexer().root_porn()
elif action == 'faith'					: thorstreams.indexer().root_faith()
elif action == 'lust'					: thorstreams.indexer().root_lust()

elif action == 'absolution'				: thorstreams.indexer().root_absolution()
elif action == 'eyecandy'				: thorstreams.indexer().root_eyecandy()
elif action == 'retribution'			: thorstreams.indexer().root_retribution()
elif action == 'kiddo'					: thorstreams.indexer().root_kiddo()
elif action == 'plist'					: thorstreams.indexer().root_personal()

elif action == 'ncaa'					: thorstreams.indexer().root_ncaa()
elif action == 'ncaab'					: thorstreams.indexer().root_ncaab()
elif action == 'lfl'					: thorstreams.indexer().root_lfl()
elif action == 'xfl'					: thorstreams.indexer().root_xfl()
elif action == 'misc_sports'			: thorstreams.indexer().root_misc_sports()
elif action == 'boxing'					: thorstreams.indexer().root_boxing()
elif action == 'tennis'					: thorstreams.indexer().root_tennis()
elif action == 'mlb'					: thorstreams.indexer().root_mlb()
elif action == 'nfl'					: thorstreams.indexer().root_nfl()
elif action == 'nhl'					: thorstreams.indexer().root_nhl()
elif action == 'nba'					: thorstreams.indexer().root_nba()
elif action == 'ufc'					: thorstreams.indexer().root_ufc()
elif action == 'fifa'					: thorstreams.indexer().root_fifa()
elif action == 'wwe'					: thorstreams.indexer().root_wwe()
elif action == 'motogp'					: thorstreams.indexer().root_motogp()
elif action == 'f1'						: thorstreams.indexer().root_f1()
elif action == 'pga'					: thorstreams.indexer().root_pga()
elif action == 'sports_channels'		: thorstreams.indexer().root_sports_channels()
elif action == 'sreplays'				: thorstreams.indexer().root_sreplays()

####################################################
#---MOVIES
####################################################
elif action == 'movieNavigator'			: navigator.navigator().movies()
elif action == 'movieliteNavigator'		: navigator.navigator().movies(lite=True)
elif action == 'mymovieNavigator'		: navigator.navigator().mymovies()
elif action == 'mymovieliteNavigator'	: navigator.navigator().mymovies(lite=True)
elif action == 'movies'					: movies.movies().get(url)
elif action == 'moviePage'				: movies.movies().get(url)
elif action == 'tmdbmovies'				: movies.movies().getTMDb(url)
elif action == 'tmdbmoviePage'			: movies.movies().getTMDb(url)
elif action == 'newMovies'				: movies.movies().newMovies()
elif action == 'movieSearch'			: movies.movies().search()
elif action == 'movieSearchnew'			: movies.movies().search_new()
elif action == 'movieSearchterm'		: movies.movies().search_term(name)
elif action == 'moviePerson'			: movies.movies().person()
elif action == 'movieGenres'			: movies.movies().genres()
elif action == 'movieLanguages'			: movies.movies().languages()
elif action == 'movieCertificates'		: movies.movies().certifications()
elif action == 'movieYears'				: movies.movies().years()
elif action == 'moviePersons'			: movies.movies().persons(url)
elif action == 'moviesUnfinished'		: movies.movies().unfinished(url)
elif action == 'movieUserlists'			: movies.movies().userlists()
elif action == 'findKeywordsMovies'		: movies.movies().findKeywords(url)
elif action == 'movieWidget'			: movies.movies().widget()

####################################################
#---Collections
####################################################
elif action == 'collectionsNavigator'	: collections.collections().collectionsNavigator()
elif action == 'collectionActors'		: collections.collections().collectionActors()
elif action == 'collectionBoxset'		: collections.collections().collectionBoxset()
elif action == 'collectionKids'			: collections.collections().collectionKids()
elif action == 'collectionBoxsetKids'	: collections.collections().collectionBoxsetKids()
elif action == 'collectionSuperhero'	: collections.collections().collectionSuperhero()
elif action == 'collections'			: collections.collections().get(url)

####################################################
#---Martial Arts Collections
####################################################
elif action == 'collection_martial_arts' : collections.collections().collection_martial_arts()
elif action == 'collection_martial_arts_actors'	: collections.collections().collection_martial_arts_actors()

####################################################
#---Furk
####################################################
elif action == "furkNavigator"			: navigator.navigator().furk()
elif action == "furkMetaSearch"			: furk.furk().furk_meta_search(url)
elif action == "furkSearch"				: furk.furk().search()
elif action == "furkUserFiles"			: furk.furk().user_files()
elif action == "furkSearchNew"			: furk.furk().search_new()

####################################################
# TV Shows
####################################################
elif action == 'tvNavigator'			: navigator.navigator().tvshows()
elif action == 'tvliteNavigator'		: navigator.navigator().tvshows(lite=True)
elif action == 'mytvNavigator'			: navigator.navigator().mytvshows()
elif action == 'mytvliteNavigator'		: navigator.navigator().mytvshows(lite=True)
elif action == 'channels'				: channels.channels().get()
elif action == 'tvshows'				: tvshows.tvshows().get(url)
elif action == 'tvshowPage'				: tvshows.tvshows().get(url)
elif action == 'tmdbTvshows'			: tvshows.tvshows().getTMDb(url)
elif action == 'tmdbTvshowPage'			: tvshows.tvshows().getTMDb(url)
elif action == 'tvmazeTvshows'			: tvshows.tvshows().getTVmaze(url)
elif action == 'tvmazeTvshowPage'		: tvshows.tvshows().getTVmaze(url)
elif action == 'tvSearch'				: tvshows.tvshows().search()
elif action == 'tvSearchnew'			: tvshows.tvshows().search_new()
elif action == 'tvSearchterm'			: tvshows.tvshows().search_term(name)
elif action == 'tvPerson'				: tvshows.tvshows().person()
elif action == 'tvGenres'				: tvshows.tvshows().genres()
elif action == 'tvNetworks'				: tvshows.tvshows().networks()
elif action == 'tvLanguages'			: tvshows.tvshows().languages()
elif action == 'tvCertificates'			: tvshows.tvshows().certifications()
elif action == 'tvPersons'				: tvshows.tvshows().persons(url)
elif action == 'tvUserlists'			: tvshows.tvshows().userlists()

####################################################
#---SEASONS & Episodes
####################################################
#elif action == 'seasons'				: episodes.seasons().get(tvshowtitle, year, imdb, tvdb)
#elif action == 'episodes'				: episodes.episodes().get(tvshowtitle, year, imdb, tvdb, season, episode)
#elif action == 'calendar'				: episodes.episodes().calendar(url)
#elif action == 'tvWidget'				: episodes.episodes().widget()
#elif action == 'calendars'				: episodes.episodes().calendars()
#elif action == 'episodeUserlists'		: episodes.episodes().userlists()

####################################################
#---SEASONS
####################################################
elif action == 'seasons'				: seasons.seasons().get(tvshowtitle, year, imdb, tvdb)
elif action == 'seasonsUserlists'		: seasons.seasons().userlists()
elif action == 'seasonsList'			: seasons.seasons().seasonList(url)

####################################################
#---EPISODES
####################################################
elif action == 'episodes'				: episodes.episodes().get(tvshowtitle, year, imdb, tvdb, season, episode)
elif action == 'episodesPage'			: episodes.episodes().get(tvshowtitle, year, imdb, tvdb, season, episode)
elif action == 'tvWidget'				: episodes.episodes().widget()
elif action == 'calendar'				: episodes.episodes().calendar(url)
elif action == 'calendars'				: episodes.episodes().calendars()
elif action == 'episodesUnfinished'		: episodes.episodes().unfinished(url)
elif action == 'episodesUserlists'		: episodes.episodes().userlists()

####################################################
#---Anime
####################################################
elif action == 'animeNavigator'			: navigator.navigator().anime()
elif action == 'animeMovies'			: movies.movies().get(url)
elif action == 'animeTVshows'			: tvshows.tvshows().get(url)

####################################################
#---Originals
####################################################
elif action == 'originals'				: tvshows.tvshows().originals()

####################################################
#---Holidays
####################################################

elif action == 'holidaysNavigator'		: navigator.navigator().holidays()
elif action == 'halloweenNavigator'		: navigator.navigator().halloween()

####################################################
#---YouTube
####################################################
elif action == 'youtube':
    from resources.lib.indexers import youtube
    if subid == None:
        youtube.yt_index().root(action)
    else:
        youtube.yt_index().get(action, subid)

#elif 'youtube1' in str(action):
#    thorstreams.indexer().youtube(url, action)

elif action == 'boxing':
    from resources.lib.indexers import youtube
    if subid == None:
        youtube.yt_index().root(action)
    else:
        youtube.yt_index().get(action, subid)

elif action == 'musicvids':
    from resources.lib.indexers import youtube
    if subid == None:
        youtube.yt_index().root(action)
    else:
        youtube.yt_index().get(action, subid)

elif action == 'news':
    from resources.lib.indexers import youtube
    if subid == None:
        youtube.yt_index().root(action)
    else:
        youtube.yt_index().get(action, subid)

elif action == 'sport':
    from resources.lib.indexers import youtube
    if subid == None:
        youtube.yt_index().root(action)
    else:
        youtube.yt_index().get(action, subid)



####################################################
#---Swift Streams
####################################################		
elif action == 'swiftNavigator'			: swift.swift().root()
elif action == 'swiftCat'				: swift.swift().swiftCategory(url)
elif action == 'swiftPlay'				: swift.swift().swiftPlay(url)
			
####################################################
#---Tools
####################################################
elif action == 'download':
	import json
	try:
		downloader.download(name, image, sources.Sources().SourcesResolve(json.loads(source)[0], True))
	except:
		pass

elif action == 'downloadNavigator'		: navigator.navigator().downloads()
elif action == 'libraryNavigator'		: navigator.navigator().library()
elif action == 'toolNavigator'			: navigator.navigator().tools()
elif action == 'searchNavigator'		: navigator.navigator().search()
elif action == 'viewsNavigator'			: navigator.navigator().views()
elif action == 'resetViewTypes'			: views.clearViews()
elif action == 'addView'				: views.addView(content)
elif action == 'refresh'				: control.refresh()
elif action == 'openSettings'			: control.openSettings(query)
elif action == 'open.Settings.CacheProviders': control.openSettings(query)
elif action == 'artwork'				: control.artwork()
elif action == 'UpNextSettings'			: control.openSettings('0.0', 'service.upnext')
elif action == 'ScraperSettings'		: control.openSettings(id='script.module.universalscrapers')	
elif action == 'ResolverSettings'		: control.openSettings(id='script.resolveurl')
elif action == 'urlresolverSettings'	: control.openSettings(id='script.module.resolveurl')
elif action == "realdebridauth"			: debrid.rdAuthorize()
elif action == 'queueItem'				: control.queueItem()
elif action == 'infoCheck'				: navigator.navigator().infoCheck('')
elif action == 'Mkeywords'				: movies.movies().keywords()
elif action == 'TVkeywords'				: tvshows.tvshows().keywords()
elif action == 'sortby'					: navigator.navigator().sortby()
elif action == 'useramount'				: navigator.navigator().listamount()

####################################################
#---Playcount
####################################################
elif action == 'moviePlaycount'			: playcount.movies(imdb, query)
elif action == 'episodePlaycount'		: playcount.episodes(imdb, tvdb, season, episode, query)
elif action == 'tvPlaycount'			: playcount.tvshows(name, imdb, tvdb, season, query)
elif action == 'trailer'				: trailer.trailer().play(name, url, windowedtrailer)

####################################################
#---Trakt
####################################################
elif action == 'traktManager'			: trakt.manager(name, imdb, tvdb, season, episode)
elif action == 'authTrakt':
	trakt.authTrakt()
	if params.get('opensettings') == 'true':
		control.openSettings(query, "plugin.video.thor")
elif action == 'cachesyncMovies'		: trakt.cachesyncMovies()
elif action == 'cachesyncTVShows'		: trakt.cachesyncTVShows()

####################################################
#---TMDb
####################################################
elif action == 'authTMDb':
	tmdb.Auth().create_session_id()
	if params.get('opensettings') == 'true':
		control.openSettings(query, "plugin.video.thor")

elif action == 'revokeTMDb':
	tmdb.Auth().revoke_session_id()
	if params.get('opensettings') == 'true':
		control.openSettings(query, "plugin.video.thor")



####################################################
#---Playlist
####################################################
elif action == 'playlistManager'		: playlist.playlistManager(name, url, meta, art)
elif action == 'showPlaylist'			: playlist.playlistShow()
elif action == 'clearPlaylist'			: playlist.playlistClear()
elif action == 'queueItem'				:
	control.queueItem()
	if name is None:
		control.notification(title = 35515, message = 35519, icon = 'INFO', sound = notificationSound)
	else:
		control.notification(title = name, message = 35519, icon = 'INFO', sound = notificationSound)


####################################################
#---Player
####################################################
elif action == 'play':
    if not content == None:
        thorstreams.player().play(url, content)
    else:
        sources.sources().play(title, year, imdb, tvdb, season, episode, tvshowtitle, premiered, meta, select, rescrape=False)		

elif action == 'play2':
    if not content == None:
        thorstreams.player().play(url, content)
    else:
        sources.sources().play(title, year, imdb, tvdb, season, episode, tvshowtitle, premiered, meta, select, rescrape=False)

elif action == 'reScrape'				: sources.sources().play(title, year, imdb, tvdb, season, episode, tvshowtitle, premiered, meta, select, rescrape=True)
elif action == 'addItem'				: sources.sources().addItem(title)
elif action == 'addItem2'				: sources2.sources().addItem2(title)
elif action == 'playItem'				: sources.sources().playItem(title, source)
elif action == 'playItem2'				: sources2.sources().playItem2(title, source)
elif action == 'alterSources'			: sources.sources().alterSources(url, meta)
elif action == 'alterSources2'			: sources2.sources().alterSources2(url, meta)
elif action == 'clearSources'			: sources.sources().clearSources()
elif action == 'clearSources2'			: sources2.sources().clearSources2()
elif action == 'disableAll'				: sources.sources().disableAll()
elif action == 'disableAll2'			: sources2.sources().disableAll2()
elif action == 'enableAll'				: sources.sources().enableAll()
elif action == 'enableAll2'				: sources2.sources().enableAll2()
	
elif action == 'random':
    rtype = params.get('rtype')
    if rtype == 'movie':
        rlist = movies.movies().get(url, create_directory=False)
        r = sys.argv[0]+"?action=play"
    elif rtype == 'episode':
        rlist = episodes.episodes().get(tvshowtitle, year, imdb, tvdb, season, create_directory=False)
        r = sys.argv[0]+"?action=play"
    elif rtype == 'season':
        rlist = episodes.seasons().get(tvshowtitle, year, imdb, tvdb, create_directory=False)
        r = sys.argv[0]+"?action=random&rtype=episode"
    elif rtype == 'show':
        rlist = tvshows.tvshows().get(url, create_directory=False)
        r = sys.argv[0]+"?action=random&rtype=season"
    from random import randint
    import json
    try:
        rand = randint(1,len(rlist))-1
        for p in ['title','year','imdb','tvdb','season','episode','tvshowtitle','premiered','select']:
            if rtype == "show" and p == "tvshowtitle":
                try: r += '&'+p+'='+urllib.quote_plus(rlist[rand]['title'])
                except: pass
            else:
                try: r += '&'+p+'='+urllib.quote_plus(rlist[rand][p])
                except: pass
        try: r += '&meta='+urllib.quote_plus(json.dumps(rlist[rand]))
        except: r += '&meta='+urllib.quote_plus("{}")
        if rtype == "movie":
            try: control.infoDialog(rlist[rand]['title'], control.lang(32536).encode('utf-8'), time=30000)
            except: pass
        elif rtype == "episode":
            try: control.infoDialog(rlist[rand]['tvshowtitle']+" - Season "+rlist[rand]['season']+" - "+rlist[rand]['title'], control.lang(32536).encode('utf-8'), time=30000)
            except: pass
        control.execute('RunPlugin(%s)' % r)
    except:
        control.infoDialog(control.lang(32537).encode('utf-8'), time=8000)

####################################################
#---Library Actions
####################################################
elif action == 'movieToLibrary'			: libtools.libmovies().add(name, title, year, imdb, tmdb)
elif action == 'moviesToLibrary'		: libtools.libmovies().range(url)
elif action == 'moviesToLibrarySilent'	: libtools.libmovies().silent(url)
elif action == 'tvshowToLibrary'		: libtools.libtvshows().add(tvshowtitle, year, imdb, tvdb)
elif action == 'tvshowsToLibrary'		: libtools.libtvshows().range(url)
elif action == 'tvshowsToLibrarySilent'	: libtools.libtvshows().silent(url)
elif action == 'updateLibrary'			: libtools.libepisodes().update(query)
elif action == 'service'				: libtools.libepisodes().service()

####################################################
#---Clear Cache actions
####################################################
elif action == 'cfNavigator'			: navigator.navigator().cf()
elif action == 'clearAllCache':
	navigator.navigator().clearCacheAll()
	if params.get('opensettings') == 'true':
		control.openSettings(query, 'plugin.video.thor')

elif action == 'clearSources':
	navigator.navigator().clearCacheProviders()
	if params.get('opensettings') == 'true':
		control.openSettings(query, 'plugin.video.thor')

elif action == 'clearMetaCache':
	navigator.navigator().clearCacheMeta()
	if params.get('opensettings') == 'true':
		control.openSettings(query, 'plugin.video.thor')

elif action == 'clearCache':
	navigator.navigator().clearCache()
	if params.get('opensettings') == 'true':
		control.openSettings(query, 'plugin.video.thor')

elif action == 'clearCacheSearch':
	navigator.navigator().clearCacheSearch() 
	if params.get('opensettings') == 'true':
		control.openSettings(query, 'plugin.video.thor')

elif action == 'clearSearchPhrase':
	navigator.navigator().clearCacheSearchPhrase(table, name)

elif action == 'clearBookmarks':
	navigator.navigator().clearBookmarks()
	if params.get('opensettings') == 'true':
		control.openSettings(query, 'plugin.video.thor')

elif action == 'clearResolveURLcache':
	if control.condVisibility('System.HasAddon(script.module.resolveurl)'):
		control.execute('RunPlugin(plugin://script.module.resolveurl/?mode=reset_cache)')