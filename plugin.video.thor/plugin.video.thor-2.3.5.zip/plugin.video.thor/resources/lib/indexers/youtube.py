# -*- coding: utf-8 -*-

'''
Thor / IT

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

from resources.lib.modules import log_utils
from resources.lib.modules import control
from resources.lib.modules import youtube
from resources.lib.modules import youtube_menu

import os,sys,re,datetime,urlparse

thishandle = int(sys.argv[1])

# initializes as Kids Corner, functions can override based on action and subid.
class yt_index:
	def __init__(self):
		self.action = 'youtube'
		self.base_url = 'https://aussiehulk.com/MyAddon/thor/youtube/'
		self.mainmenu = '%sytmain.txt' % (self.base_url)
	#        self.submenu  = '%s/%s.txt'
		self.default_icon   = '%s/icons/icon.png'
		self.default_fanart = '%s/icons/fanart.jpg'


	def init_vars(self, action):
		try:
			if action == 'boxing':
				self.action   = 'boxing'
				self.base_url = 'https://aussiehulk.com/MyAddon/thor/youtube/'
				self.mainmenu = '%sboxing.txt' % (self.base_url)
			elif action == 'youtube':
				self.action   = 'youtube'
				self.base_url = 'https://aussiehulk.com/MyAddon/thor/youtube/'
				self.mainmenu = '%sytmain.txt' % (self.base_url)
			elif action == 'sports':
				self.action   = 'sports'
				self.base_url = 'https://aussiehulk.com/MyAddon/thor/youtube/'
				self.mainmenu = '%ssports.txt' % (self.base_url)
			elif action == 'news':
				self.action   = 'news'
				self.base_url = 'https://aussiehulk.com/MyAddon/thor/youtube/'
				self.mainmenu = '%snews.txt' % (self.base_url)
			elif action == 'musicvids':
				self.action   = 'musicvids'
				self.base_url = 'https://aussiehulk.com/MyAddon/thor/youtube/'
				self.mainmenu = '%smusicvids.txt' % (self.base_url)
			self.submenu = self.submenu % (self.base_url, '%s')
			self.default_icon = self.default_icon % (self.base_url)
			self.default_fanart = self.default_fanart % (self.base_url)
		except:
			pass

	def root(self, action):
		try:
			self.init_vars(action)
			menuItems = youtube_menu.youtube_menu().processMenuFile(self.mainmenu)
			for name,section,searchid,subid,playlistid,channelid,videoid,iconimage,fanart,description in menuItems:
				if not subid == 'false': # Means this item points to a submenu
					youtube_menu.youtube_menu().addMenuItem(name, self.action, subid, iconimage, fanart, description, True)
				elif not searchid == 'false': # Means this is a search term
					youtube_menu.youtube_menu().addSearchItem(name, searchid, iconimage, fanart)
				elif not videoid == 'false': # Means this is a video id entry
					youtube_menu.youtube_menu().addVideoItem(name, videoid, iconimage, fanart)
				elif not channelid == 'false': # Means this is a channel id entry
					youtube_menu.youtube_menu().addChannelItem(name, channelid, iconimage, fanart)
				elif not playlistid == 'false': # Means this is a playlist id entry
					youtube_menu.youtube_menu().addPlaylistItem(name, playlistid, iconimage, fanart)
				elif not section == 'false': # Means this is a section placeholder/info line
					youtube_menu.youtube_menu().addSectionItem(name, self.default_icon, self.default_fanart)
			self.endDirectory()
		except:
			pass

	def get(self, action, subid):
		try:
			self.init_vars(action)
			thisMenuFile = self.submenu % (subid)
			menuItems = youtube_menu.youtube_menu().processMenuFile(thisMenuFile)
			for name,section,searchid,subid,playlistid,channelid,videoid,iconimage,fanart,description in menuItems:
				if not subid == 'false': # Means this item points to a submenu
					youtube_menu.youtube_menu().addMenuItem(name, self.action, subid, iconimage, fanart, description, True)
				elif not searchid == 'false': # Means this is a search term
					youtube_menu.youtube_menu().addSearchItem(name, searchid, iconimage, fanart)
				elif not videoid == 'false': # Means this is a video id entry
					youtube_menu.youtube_menu().addVideoItem(name, videoid, iconimage, fanart)
				elif not channelid == 'false': # Means this is a channel id entry
					youtube_menu.youtube_menu().addChannelItem(name, channelid, iconimage, fanart)
				elif not playlistid == 'false': # Means this is a playlist id entry
					youtube_menu.youtube_menu().addPlaylistItem(name, playlistid, iconimage, fanart)
				elif not section == 'false': # Means this is a section placeholder/info line
					youtube_menu.youtube_menu().addSectionItem(name, self.default_icon, self.default_fanart)
			self.endDirectory()
		except:
			pass

	def endDirectory(self):
		control.directory(thishandle, cacheToDisc=True)
