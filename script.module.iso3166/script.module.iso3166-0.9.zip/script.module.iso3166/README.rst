script.module.iso3166
=====================

ISO 3166-1 library repacked for Kodi

- https://github.com/back-to/script.module.iso3166

Based on ISO 3166-1 library for Python.

- https://github.com/deactivated/python-iso3166
- https://pypi.python.org/pypi/iso3166/0.9

License
-------

MIT License
