"""
    air_table4k.py
    Copyright (C) 2018,
    Version 1.0.2

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    -------------------------------------------------------------

    Usage Examples:


    Returns the 4K Movies list-

    <dir>
    <title>$k Movies</title>
    <Airtable4k>4kmovies</Airtable4k>
    </dir>


    Returns the 4K TV Shows list-

    <dir>
    <title>4K Tv Shows</title>
    <Airtable4k>4ktv_shows</Airtable4k>
    </dir>


    --------------------------------------------------------------

"""



from __future__ import absolute_import
import requests
import re
import os
import xbmc
import xbmcaddon
import json
from koding import route
from ..plugin import Plugin
from resources.lib.external.airtable.airtable import Airtable
from resources.lib.util.context import get_context_items
from resources.lib.util.xml import JenItem, JenList, display_list
from requests.exceptions import HTTPError
import time
from unidecode import unidecode

CACHE_TIME = 3600  # change to wanted cache time in seconds

addon_fanart = xbmcaddon.Addon().getAddonInfo('fanart')
addon_icon = xbmcaddon.Addon().getAddonInfo('icon')
AddonName = xbmc.getInfoLabel('Container.PluginName')
AddonName = xbmcaddon.Addon(AddonName).getAddonInfo('id')


class AIRTABLE4k(Plugin):
    name = "airtable4k"

    def process_item(self, item_xml):
        if "<Airtable4k>" in item_xml:
            item = JenItem(item_xml)
            if "4kmovies" in item.get("Airtable4k", ""):
                result_item = {
                    'label': item["title"],
                    'icon': item.get("thumbnail", addon_icon),
                    'fanart': item.get("fanart", addon_fanart),
                    'mode': "open_4k_movies",
                    'url': "",
                    'folder': True,
                    'imdb': "0",
                    'season': "0",
                    'episode': "0",
                    'info': {},
                    'year': "0",
                    'context': get_context_items(item),
                    "summary": item.get("summary", None)
                }
                result_item["properties"] = {
                    'fanart_image': result_item["fanart"]
                }
                result_item['fanart_small'] = result_item["fanart"]
                return result_item

            elif "4ktv_shows" in item.get("Airtable4k", ""):
                result_item = {
                    'label': item["title"],
                    'icon': item.get("thumbnail", addon_icon),
                    'fanart': item.get("fanart", addon_fanart),
                    'mode': "open_4k_tv_shows",
                    'url': "",
                    'folder': True,
                    'imdb': "0",
                    'season': "0",
                    'episode': "0",
                    'info': {},
                    'year': "0",
                    'context': get_context_items(item),
                    "summary": item.get("summary", None)
                }
                result_item["properties"] = {
                    'fanart_image': result_item["fanart"]
                }
                result_item['fanart_small'] = result_item["fanart"]
                return result_item                
                

@route(mode='open_4k_movies')
def open_movies():
    xml = ""
    at = Airtable('appJgRUQhuA0xVxIX', '4kmovies', api_key='keyOHaxsTGzHU9EEh')
    match = at.get_all(maxRecords=2000, sort=['channel'])
    for field in match:
        try:
            res = field['fields']
            channel = res['channel']
            thumbnail = res['thumbnail']
            fanart = res['fanart']
            link = res['link']
            summary = res['summary']
            summary = remove_non_ascii(summary)
            if "plugin" in link:

                xml += "<plugin>"\
                       "<title>%s</title>"\
                       "<meta>"\
                       "<content>movie</content>"\
                       "<imdb></imdb>"\
                       "<title>%s</title>"\
                       "<year></year>"\
                       "<thumbnail>%s</thumbnail>"\
                       "<fanart>%s</fanart>"\
                       "<summary>%s</summary>"\
                       "</meta>"\
                       "<link>"\
                       "<sublink>%s</sublink>"\
                       "</link>"\
                       "</plugin>" % (channel,channel,thumbnail,fanart,summary,link)
                    
            else:
                xml +=  "<item>"\
                        "<title>%s</title>"\
                        "<meta>"\
                        "<content>movie</content>"\
                        "<imdb></imdb>"\
                        "<title>%s</title>"\
                        "<year></year>"\
                        "<thumbnail>%s</thumbnail>"\
                        "<fanart>%s</fanart>"\
                        "<summary>%s</summary>"\
                        "</meta>"\
                        "<link>"\
                        "<sublink>%s</sublink>"\
                        "</link>"\
                        "</item>" % (channel,channel,thumbnail,fanart,summary,link)
        except:
            pass                
    jenlist = JenList(xml)
    display_list(jenlist.get_list(), jenlist.get_content_type())


@route(mode='open_4k_tv_shows')
def open_tv_shows():
    xml = ""
    at = Airtable('apppVCDzOzx143aDx', '4ktvshows', api_key='keyOHaxsTGzHU9EEh')
    match = at.get_all(maxRecords=2000, view='Grid view')
    for field in match:
        try:
            res = field['fields']
            channel = res['channel']
            thumbnail = res['thumbnail']
            fanart = res['fanart']
            link = res['link']
            summary = res['summary']
            summary = remove_non_ascii(summary)
            if "plugin" in link:

                xml += "<plugin>"\
                       "<title>%s</title>"\
                       "<meta>"\
                       "<content>movie</content>"\
                       "<imdb></imdb>"\
                       "<title>%s</title>"\
                       "<year></year>"\
                       "<thumbnail>%s</thumbnail>"\
                       "<fanart>%s</fanart>"\
                       "<summary>%s</summary>"\
                       "</meta>"\
                       "<link>"\
                       "<sublink>%s</sublink>"\
                       "</link>"\
                       "</plugin>" % (channel,channel,thumbnail,fanart,summary,link)
                    
            else:
                xml +=  "<item>"\
                        "<title>%s</title>"\
                        "<meta>"\
                        "<content>movie</content>"\
                        "<imdb></imdb>"\
                        "<title>%s</title>"\
                        "<year></year>"\
                        "<thumbnail>%s</thumbnail>"\
                        "<fanart>%s</fanart>"\
                        "<summary>%s</summary>"\
                        "</meta>"\
                        "<link>"\
                        "<sublink>%s</sublink>"\
                        "</link>"\
                        "</item>" % (channel,channel,thumbnail,fanart,summary,link)
        except:
            pass                
    jenlist = JenList(xml)
    display_list(jenlist.get_list(), jenlist.get_content_type())

def remove_non_ascii(text):
    return unidecode(text)
        
