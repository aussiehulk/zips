"""
    releases.py 
    Copyright (C) 2018
    Version 3.0.0

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    -------------------------------------------------------------

    Usage Examples:

    Returns the Newest Releases List-

    <dir>
    <title>Newest Releases List</title>
    <Newest>display</Newest>
    </dir>


    --------------------------------------------------------------

"""



from __future__ import absolute_import
import requests
import re
import os
import xbmc,xbmcgui
import xbmcaddon
import json
import __builtin__
from koding import route
from ..plugin import Plugin
from resources.lib.external.airtable.airtable import Airtable
from resources.lib.util.context import get_context_items
from resources.lib.util.xml import JenItem, JenList, display_list
from requests.exceptions import HTTPError
import time
from unidecode import unidecode

CACHE_TIME = 3600  # change to wanted cache time in seconds

TMDB_api_key = __builtin__.tmdb_api_key
addon_fanart = xbmcaddon.Addon().getAddonInfo('fanart')
addon_icon = xbmcaddon.Addon().getAddonInfo('icon')
AddonName = xbmc.getInfoLabel('Container.PluginName')
AddonName = xbmcaddon.Addon(AddonName).getAddonInfo('id')
addon_id     = xbmcaddon.Addon().getAddonInfo('id')
dialog       = xbmcgui.Dialog()
home_folder  = xbmc.translatePath('special://home/')
addon_folder = os.path.join(home_folder,'addons')
art_path     = os.path.join(addon_folder,addon_id)
xml_path     = os.path.join(art_path,'xml')
File = os.path.join(xml_path,'newest')



class Release_list(Plugin):
    name = "newest"

    def process_item(self, item_xml):
        if "<Newest>" in item_xml:
            item = JenItem(item_xml)            
            result_item = {
                'label': item["title"],
                'icon': item.get("thumbnail", addon_icon),
                'fanart': item.get("fanart", addon_fanart),
                'mode': "newest_list",
                'url': item.get("Newest", ""),
                'folder': True,
                'imdb': "0",
                'season': "0",
                'episode': "0",
                'info': {},
                'year': "0",
                'context': get_context_items(item),
                "summary": item.get("summary", None)
            }
            result_item["properties"] = {
                'fanart_image': result_item["fanart"]
            }
            result_item['fanart_small'] = result_item["fanart"]
            return result_item                                   
                               
        
@route(mode='newest_list', args=["url"])
def newest_List(url):
    if "display" in url:
        xml = ""

        xml += "<dir>"\
               "<title>[COLOR=orange]View Newest Releases[/COLOR]</title>"\
               "<link>file://newest.xml</link>"\
               "</dir>"

        xml += "<dir>"\
               "<title>[COLOR=orange]Update Movie List[/COLOR]</title>"\
               "<Newest>newest_releases</Newest>"\
               "</dir>"

        jenlist = JenList(xml)
        display_list(jenlist.get_list(), jenlist.get_content_type())

    elif "newest_releases" in url:       
        open('%s.xml'%(File),'w')
        at = Airtable('app4O4BNC5yEy9wNa', 'Releases_Newest', api_key='keyOHaxsTGzHU9EEh')
        match = at.get_all(maxRecords=700, view='Grid view')
        for field in match:
            try:
                res = field['fields']
                title = res['title']
                tmdb = res['tmdb']
                year = res['year']
                link1 = res['link1']
                link2 = res['link2']
                link3 = res['link3']
                link4 = res['link4']
                link5 = res['link5']
                if "-*-" in link2:
                    (thumbnail, fanart, imdb) = pull_tmdb(title,year,tmdb)
                    title = remove_non_ascii(title)
                    link2 = link2.replace("-*-","")
                    f = open('%s.xml'%(File),'a')
                    f.write('<item>\n')
                    f.write('\t<title>%s</title>\n' % title)
                    f.write('\t<meta>\n')
                    f.write('\t<imdb>%s</imdb>\n' % imdb)
                    f.write('\t<content>movie</content>\n')
                    f.write('\t<title>%s</title>\n' % title)
                    f.write('\t<year>%s</year>\n' % year)
                    f.write('\t</meta>\n')
                    f.write('\t<link>\n')
                    f.write('\t<sublink>%s</sublink>"\n' % link1)
                    f.write('\t<sublink>%s</sublink>\n' % "search")
                    f.write('\t<sublink>%s</sublink>\n' % "searchsd")
                    f.write('\t</link>\n')
                    f.write('\t<thumbnail>%s</thumbnail>\n' % thumbnail)
                    f.write('\t<fanart>%s</fanart>\n' % fanart)
                    f.write('</item>\n')
                    f.close()                

                elif "-*-" in link3:
                    (thumbnail, fanart, imdb) = pull_tmdb(title,year,tmdb)
                    title = remove_non_ascii(title)
                    link3 = link3.replace("-*-","")
                    f = open('%s.xml'%(File),'a')
                    f.write('<item>\n')
                    f.write('\t<title>%s</title>\n' % title)
                    f.write('\t<meta>\n')
                    f.write('\t<imdb>%s</imdb>\n' % imdb)
                    f.write('\t<content>movie</content>\n')
                    f.write('\t<title>%s</title>\n' % title)
                    f.write('\t<year>%s</year>\n' % year)
                    f.write('\t</meta>\n')
                    f.write('\t<link>\n')
                    f.write('\t<sublink>%s</sublink>"\n' % link1)
                    f.write('\t<sublink>%s</sublink>"\n' % link2)
                    f.write('\t<sublink>%s</sublink>\n' % "search")
                    f.write('\t<sublink>%s</sublink>\n' % "searchsd")
                    f.write('\t</link>\n')
                    f.write('\t<thumbnail>%s</thumbnail>\n' % thumbnail)
                    f.write('\t<fanart>%s</fanart>\n' % fanart)
                    f.write('</item>\n')
                    f.close()
                     
                elif "-*-" in link4:
                    (thumbnail, fanart, imdb) = pull_tmdb(title,year,tmdb)
                    title = remove_non_ascii(title)
                    link4 = link4.replace("-*-","")
                    f = open('%s.xml'%(File),'a')
                    f.write('<item>\n')
                    f.write('\t<title>%s</title>\n' % title)
                    f.write('\t<meta>\n')
                    f.write('\t<imdb>%s</imdb>\n' % imdb)
                    f.write('\t<content>movie</content>\n')
                    f.write('\t<title>%s</title>\n' % title)
                    f.write('\t<year>%s</year>\n' % year)
                    f.write('\t</meta>\n')
                    f.write('\t<link>\n')
                    f.write('\t<sublink>%s</sublink>"\n' % link1)
                    f.write('\t<sublink>%s</sublink>"\n' % link2)
                    f.write('\t<sublink>%s</sublink>"\n' % link3)
                    f.write('\t<sublink>%s</sublink>\n' % "search")
                    f.write('\t<sublink>%s</sublink>\n' % "searchsd")
                    f.write('\t</link>\n')
                    f.write('\t<thumbnail>%s</thumbnail>\n' % thumbnail)
                    f.write('\t<fanart>%s</fanart>\n' % fanart)
                    f.write('</item>\n')
                    f.close()
                                       
                elif "-*-" in link5:
                    (thumbnail, fanart, imdb) = pull_tmdb(title,year,tmdb)
                    title = remove_non_ascii(title)
                    link5 = link5.replace("-*-","")
                    f = open('%s.xml'%(File),'a')
                    f.write('<item>\n')
                    f.write('\t<title>%s</title>\n' % title)
                    f.write('\t<meta>\n')
                    f.write('\t<imdb>%s</imdb>\n' % imdb)
                    f.write('\t<content>movie</content>\n')
                    f.write('\t<title>%s</title>\n' % title)
                    f.write('\t<year>%s</year>\n' % year)
                    f.write('\t</meta>\n')
                    f.write('\t<link>\n')
                    f.write('\t<sublink>%s</sublink>"\n' % link1)
                    f.write('\t<sublink>%s</sublink>"\n' % link2)
                    f.write('\t<sublink>%s</sublink>"\n' % link3)
                    f.write('\t<sublink>%s</sublink>"\n' % link4)
                    f.write('\t<sublink>%s</sublink>\n' % "search")
                    f.write('\t<sublink>%s</sublink>\n' % "searchsd")
                    f.write('\t</link>\n')
                    f.write('\t<thumbnail>%s</thumbnail>\n' % thumbnail)
                    f.write('\t<fanart>%s</fanart>\n' % fanart)
                    f.write('</item>\n')
                    f.close()
                      
                else:
                    (thumbnail, fanart, imdb) = pull_tmdb(title,year,tmdb)
                    title = remove_non_ascii(title)                  
                    f = open('%s.xml'%(File),'a')
                    f.write('<item>\n')
                    f.write('\t<title>%s</title>\n' % title)
                    f.write('\t<meta>\n')
                    f.write('\t<imdb>%s</imdb>\n' % imdb)
                    f.write('\t<content>movie</content>\n')
                    f.write('\t<title>%s</title>\n' % title)
                    f.write('\t<year>%s</year>\n' % year)
                    f.write('\t</meta>\n')
                    f.write('\t<link>\n')
                    f.write('\t<sublink>%s</sublink>"\n' % link1)
                    f.write('\t<sublink>%s</sublink>"\n' % link2)
                    f.write('\t<sublink>%s</sublink>"\n' % link3)
                    f.write('\t<sublink>%s</sublink>"\n' % link4)
                    f.write('\t<sublink>%s</sublink>"\n' % link5)
                    f.write('\t<sublink>%s</sublink>\n' % "search")
                    f.write('\t<sublink>%s</sublink>\n' % "searchsd")
                    f.write('\t</link>\n')
                    f.write('\t<thumbnail>%s</thumbnail>\n' % thumbnail)
                    f.write('\t<fanart>%s</fanart>\n' % fanart)
                    f.write('</item>\n')
                    f.close()
            except:
                pass

def pull_tmdb(title,year,tmdb):
    try:
        search_title = title.replace(" ", "%20")
        url = 'https://api.themoviedb.org/3/movie/%s?api_key=586aa0e416c8d3350aee09a2ebc178ac&language=en-US' % tmdb
        html = requests.get(url).content
        match = json.loads(html)
        thumbnail = (match['poster_path'])
        fanart = (match['backdrop_path'])
        imdb = (match['imdb_id'])
        thumbnail = "https://image.tmdb.org/t/p/original"+str(thumbnail)
        fanart = "https://image.tmdb.org/t/p/original"+str(fanart)
        return thumbnail,fanart,imdb

    except:
        return "","",""      


def remove_non_ascii(text):
    return unidecode(text)

