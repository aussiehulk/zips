"""

    Copyright (C) 2018, TonyH

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    -------------------------------------------------------------

    Usage Examples:

<dir>
<title>Live Cams</title>
<livecams>categories</livecams>
</dir>

"""    

import requests,re,json,os
import koding
import __builtin__
import xbmc,xbmcaddon
from koding import route
from resources.lib.plugin import Plugin
from resources.lib.util.context import get_context_items
from resources.lib.util.xml import JenItem, JenList, display_list
from unidecode import unidecode

CACHE_TIME = 3600  # change to wanted cache time in seconds

addon_fanart = xbmcaddon.Addon().getAddonInfo('fanart')
addon_icon = xbmcaddon.Addon().getAddonInfo('icon')
User_Agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36'

class Explore_Livecams(Plugin):
    name = "explore_livecams"

    def process_item(self, item_xml):
        if "<livecams>" in item_xml:
            item = JenItem(item_xml)
            result_item = {
                'label': item["title"],
                'icon': item.get("thumbnail", addon_icon),
                'fanart': item.get("fanart", addon_fanart),
                'mode': "live_categories",
                'url': item.get("livecams", ""),
                'folder': True,
                'imdb': "0",
                'content': "files",
                'season': "0",
                'episode': "0",
                'info': {},
                'year': "0",
                'context': get_context_items(item),
                "summary": item.get("summary", None)
            }
            result_item["properties"] = {
                'fanart_image': result_item["fanart"]
            }
            result_item['fanart_small'] = result_item["fanart"]
            return result_item


@route(mode='live_categories', args=["url"])
def get_game(url):
    xml = ""
    if url == "categories":    
        try:    
            Categories = ["Bears","Birds","Oceans","Dog Bless You","Cat Rescues","Farm Sanctuary","Honey Bees","Zen Cams","Nature Films"]
            for categ in Categories:
                (thumbnail) = get_thumb(categ)
                Page = categ.replace(" ","-").lower()                                                                                                                                                                  
                xml +=  "<item>"\
                    "<title>%s</title>"\
                    "<thumbnail>%s</thumbnail>"\
                    "<fanart></fanart>"\
                    "<summary></summary>"\
                    "<livecams>category/%s/%s</livecams>"\
                    "</item>" % (categ,thumbnail,Page,categ)
        except:
            pass

    elif "category" in url:
        try:
            categ = url.split("/")[-1]
            (thumbnail) = get_thumb(categ)
            cat = get_cat(categ)
            gory = cat.split("/")[0]
            url2 = "https://explore.org/livecams/"+cat
            html = requests.get(url2).content
            block = re.compile('<script>window.__initialState__ (.+?)printable_name',re.DOTALL).findall(html)
            match = re.compile('"title": "(.+?)".+?"primary_canonical_cam_group_slug": "(.+?)".+?"slug": "(.+?)"',re.DOTALL).findall(str(block))
            for name,first,second in match:
                if gory in first:
                    xml +=  "<item>"\
                        "<title>%s</title>"\
                        "<thumbnail>%s</thumbnail>"\
                        "<fanart></fanart>"\
                        "<summary></summary>"\
                        "<livecams>page/%s/%s/%s</livecams>"\
                        "</item>" % (name,thumbnail,name,first,second)                    
        except:
            pass
    elif "page" in url:
        try:
            name = url.split("/")[-3]
            first = url.split("/")[-2]
            second = url.split("/")[-1]
            url2 = "https://explore.org/livecams/"+first+"/"+second
            html = requests.get(url2).content
            block = re.compile('<meta content=(.+?)<meta name=',re.DOTALL).findall(html)
            match = re.compile('<link href="(.+?)"',re.DOTALL).findall(str(block))
            thumbnail = match[0]
            sub_link = match[1]
            link = "plugin://plugin.video.SportsDevil/?mode=1&amp;item=catcher%3dstreams%26url="+sub_link+"|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36"            
            xml += "<plugin>"\
                   "<title>%s</title>"\
                   "<meta>"\
                   "<content>movie</content>"\
                   "<imdb></imdb>"\
                   "<title>%s</title>"\
                   "<year></year>"\
                   "<thumbnail>%s</thumbnail>"\
                   "<fanart></fanart>"\
                   "<summary></summary>"\
                   "</meta>"\
                   "<link>"\
                   "<sublink>%s</sublink>"\
                   "</link>"\
                   "</plugin>" % (name,name,thumbnail,link)
        except:
            pass
                         
    jenlist = JenList(xml)
    display_list(jenlist.get_list(), jenlist.get_content_type()) 
              
def get_thumb(categ):
    if categ == "Bears":
        thumbnail = "https://files.explore.org/files/Poster_LivecamGroup_ThreeBears_300x450.jpg"
        gory = "three-bears/polar-bear-ouwehand-zoo-cam" 
    elif categ == "Birds":
        thumbnail = "https://files.explore.org/files/Poster_LivecamGroup_BirdersParadise_300X450.jpg"
        gory = "birds/decorah-eagles"
    elif categ == "Oceans":
        thumbnail = "https://files.explore.org/files/Poster_LivecamGroup_Oceans_300x450.jpg"
        gory = "oceans/pacific-aquarium-tropical-reef-camera"
    elif categ == "Dog Bless You":
        thumbnail = "https://files.explore.org/files/DBY-IWantYou_v3_300x450.jpg"
        gory = "dog-bless-you/great-danes-donkey-hill"
    elif categ == "Cat Rescues":
        thumbnail = "https://files.explore.org/files/Poster_LivecamGroup_CatRescues_300x450.jpg"
        gory = "cats/kitten-rescue-cam"
    elif categ == "Farm Sanctuary":
        thumbnail = "https://files.explore.org/files/Poster_LivecamGroup_FarmSanctuary_300x450.jpg"
        gory = "farm-sanctuary/sheep-barn-farm-sanctuary"
    elif categ == "Honey Bees":
        thumbnail = "https://files.explore.org/files/Poster_LivecamGroup_HoneyBees_300x450.jpg"
        gory = "honey-bees/honey-bee-landing-zone-cam"        
    elif categ == "Zen Cams":
        thumbnail = "https://files.explore.org/files/Poster_LivecamGroup_ZenDen_300X450.jpg"
        gory = "zen-den/northern-lights-cam"
    elif categ == "Nature Films":
        thumbnail = "https://files.explore.org/files/Poster_LivecamGroup_NatureMeditation_300x450.jpg"
        gory = "meditation/waikiki-beach-meditation"
    return thumbnail

def get_cat(categ):
    if categ == "Bears":
        cat = "three-bears/polar-bear-ouwehand-zoo-cam" 
    elif categ == "Birds":
        cat = "birds/decorah-eagles"
    elif categ == "Oceans":
        cat = "oceans/pacific-aquarium-tropical-reef-camera"
    elif categ == "Dog Bless You":
        cat = "dog-bless-you/great-danes-donkey-hill"
    elif categ == "Cat Rescues":
        cat = "cats/kitten-rescue-cam"
    elif categ == "Farm Sanctuary":
        cat = "farm-sanctuary/sheep-barn-farm-sanctuary"
    elif categ == "Honey Bees":
        cat = "honey-bees/honey-bee-landing-zone-cam"        
    elif categ == "Zen Cams":
        cat = "zen-den/northern-lights-cam"
    elif categ == "Nature Films":
        cat = "meditation/waikiki-beach-meditation"
    return cat 

def remove_non_ascii(text):
    return unidecode(text)
           
