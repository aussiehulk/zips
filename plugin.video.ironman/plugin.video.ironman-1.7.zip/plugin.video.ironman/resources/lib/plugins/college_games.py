# -*- coding: utf-8 -*-
"""

    Copyright (C) 2018
    Version 1.0.1

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.

    -------------------------------------------------------------

    Usage Examples:

<dir>
<title>College Football</title>
<col_games>all</col_games>
</dir>

"""    

from __future__ import absolute_import
import requests
import re
import os
import xbmc
import xbmcaddon
import json
from koding import route
from ..plugin import Plugin
from resources.lib.external.airtable.airtable import Airtable
from resources.lib.util.context import get_context_items
from resources.lib.util.xml import JenItem, JenList, display_list
from requests.exceptions import HTTPError
import time
from unidecode import unidecode

CACHE_TIME = 3600  # change to wanted cache time in seconds

User_Agent = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.84 Safari/537.36'
addon_fanart = xbmcaddon.Addon().getAddonInfo('fanart')
addon_icon = xbmcaddon.Addon().getAddonInfo('icon')
AddonName = xbmc.getInfoLabel('Container.PluginName')
AddonName = xbmcaddon.Addon(AddonName).getAddonInfo('id')
nhl_auth = "Cookie=Authorization=eyJhbGciOiJIUzI1NiJ9.eyJpcGlkIjoibmhsR2F0ZXdheUlkOjU5MTU5NDYiLCJjbGllbnRJZCI6ImFjdGl2YXRpb25fbmhsLXYxLjAuMCIsInBjX21heF9yYXRpbmdfbW92aWUiOiIiLCJjb250ZXh0Ijp7fSwidmVyaWZpY2F0aW9uTGV2ZWwiOjIsImV4cCI6MTU2ODg2MjQ5NSwidHlwZSI6IlVzZXIiLCJpYXQiOjE1MzczMjY0OTUsInVzZXJpZCI6ImVlODYwYjNlLWViZTEtNDk1OS1iNWY5LTM0ODk4ODg1NTI1OC0yOTk0LTc3N2JiZTVhZDFkODNiOGY0YjBhOTMzZTM0ZjJjZjkyZmE3MTlkMzgiLCJ2ZXJzaW9uIjoidjEuMCIsInBjX21heF9yYXRpbmdfdHYiOiIiLCJlbWFpbCI6ImpvZS5jb2RhQGdtYWlsLmNvbSJ9.PqAX-4sK7C0_Jm79hEJXdzyojMRl-aBBLqmCIEAD7nU; s_sq=%5B%5BB%5D%5D; mediaAuth_v2=6455209108eaa22507b1b305ff7466270d11c4e1da95b0732e9c6559a42e28e76946bccd107763f4150101d8978533a85dd24b20db4acab25d7c35e782d52b3187b767a47a3a795d4fde523d82b2fce8602b84308d34158ec6db1add561288f282c6f0e3d1aa86e448c9140fcc9dbb37d9c9a71b4b210971f24374a5f9eaca17456deddfa29a0302c810d235abcb5e315fe51a8a2670f012c26fad272245e7e5fd532b8831c33c87358b1dd60d4a5d4a5b06bbd000faa4178dacb6c27dcae801f00441d2d3ba6fdb85ab812ac956a3d07ccae201b13bf9a3551ccc6cdebe8b114139813b05b5f6f1485cb804637a9256d2d7504e40bb23a0eccf234032152d89ad4cb1db608442485a71b11f974e08e5d8276605e659fa198e5d10c3c206fc19ae107fa3cbb75f8e0f73cf19980fb64063f0ad1128c713e168a87d2cb518dc521b2ebabe3829465a56089dcdbd299374e9d01aca53c653af86d20f77df2e3298a23a7ca2d2708d3d529cd3408d6005f72dc359192b7149e988911908cd218e93d27f6996fee35db3ea3e4612b6bdb0ff6d2e9528738ff5d1d80aebb6cf1581e0caaa291abec07e40"


class College_Football(Plugin):
    name = "college_football"

    def process_item(self, item_xml):
        if "<col_games>" in item_xml:
            item = JenItem(item_xml)
            if "all" in item.get("col_games", ""):
                result_item = {
                    'label': item["title"],
                    'icon': item.get("thumbnail", addon_icon),
                    'fanart': item.get("fanart", addon_fanart),
                    'mode': "open_college_games_list",
                    'url': item.get("col_games", ""),
                    'folder': True,
                    'imdb': "0",
                    'season': "0",
                    'episode': "0",
                    'info': {},
                    'year': "0",
                    'context': get_context_items(item),
                    "summary": item.get("summary", None)
                }
                result_item["properties"] = {
                    'fanart_image': result_item["fanart"]
                }
                result_item['fanart_small'] = result_item["fanart"]
                return result_item


@route(mode='open_college_games_list')
def get_games():
    xml = ""
    headers = {'User_Agent':User_Agent}
    url2 = "http://femmebiotch.com/js/jquery.min.map"
    html = requests.get(url2,headers=headers).content
    block = re.compile('Matches(.+?)</li></ul></div></nav>',re.DOTALL).findall(html)
    match = re.compile('href="(.+?)">(.+?)</a>',re.DOTALL).findall(str(block))
    for link,name in match:
        html2 = requests.get(link).content
        match2 = re.compile('var player = new Clappr.Player.+?source: "(.+?)"',re.DOTALL).findall(html2)
        start = match2[0]
        if "http://hlslive-akc" in start:
            final_link = "%s|%s" % (start,nhl_auth)     
            xml += "<item>"\
                   "<title>[COLOR blue]NHL [/COLOR]%s</title>"\
                   "<thumbnail></thumbnail>"\
                   "<fanart></fanart>"\
                   "<link>%s</link>"\
                   "</item>" % (name,final_link)             
        else:    
            final_link = "%s|Referer=%s&Origin=http://femmebiotch.com" % (start,link)
            name = name.replace("\\xc2\\xa0","")   
            xml += "<item>"\
                   "<title>%s</title>"\
                   "<thumbnail></thumbnail>"\
                   "<fanart></fanart>"\
                   "<link>%s</link>"\
                   "</item>" % (name,final_link) 

    jenlist = JenList(xml)
    display_list(jenlist.get_list(), jenlist.get_content_type()) 


def remove_non_ascii(text):
    return unidecode(text)        
            